public class Predmet {

    String nazivPredmeta;

    public Predmet(String nazivPredmeta) {
        this.nazivPredmeta = nazivPredmeta;
    }
}
