public class ispit  extends  Predmet {

    String datumOdrzavanja;

    public ispit(String nazivPredmeta, String datumOdrzavanja) {
        super(nazivPredmeta);
        this.datumOdrzavanja = datumOdrzavanja;
    }
}
