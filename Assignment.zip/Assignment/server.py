import socket
import random

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind(("localhost", 8005))
server_socket.listen()


client, addr = server_socket.accept()

server_number = random.randint(1, 10)
print("Server random broj: ", server_number)

data = client.recv(1024).decode()
client_number = int(data)

if client_number == server_number:
    response = "True"
else:
    response = "False"

client.send(response.encode("utf-8"))

client.close()
server_socket.close()